#include "MGEpch.h"
#include "Test.h"
#include <stdio.h>

namespace MyGameEngine {

	void Print() {
		printf("Hello world!\n");
	}

}
