#include "MGEpch.h"
#include "RendererAPI.h"

namespace MGE {

	RendererAPI::API RendererAPI::s_API = RendererAPI::API::OpenGL;

}