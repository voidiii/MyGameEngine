#include "MGEpch.h"
#include "Layer.h"

namespace MGE {

    Layer::Layer(const std::string& name)
        : m_DebugName(name)
    {
    }

    Layer::~Layer()
    {
    }

}

