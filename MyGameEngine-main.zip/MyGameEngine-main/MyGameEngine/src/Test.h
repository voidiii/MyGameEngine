#pragma once

namespace MyGameEngine {
	
	__declspec(dllexport) void Print();

}